# Assignment Frontend using NEXT JS.
 
