import '../public/assets/css/vendor/bootstrap.min.css';
import '../public/assets/css/style.css';

export default function MyApp({ Component, pageProps }) {
  return <Component {...pageProps} />;
}
