
export default function DataNotFound() {
    return (
      <div className="my-5 p-3 text-center">
          <h3><b>Data Not Found!</b></h3>
      </div>
    );
  }
  